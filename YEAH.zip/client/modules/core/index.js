
import routes from './routes.jsx';

export default {
    routes
};
