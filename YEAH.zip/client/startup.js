import {Meteor} from 'meteor/meteor';
import {Nav} from '/lib/collections';

Meteor.startup(()=>{
  /*var nav = [{name: 'Home', route: 'home', order: 0},
  {name: 'News', route: 'news', order: 1},
  {name: 'Our Mission', route: 'mission', order: 2},
  {name: 'Members', route: 'members', order: 3},
  {name: 'Contact Us', route: 'contact', order: 4}]
  Nav.insert({nav: nav});*/
});
